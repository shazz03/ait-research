﻿using AITSurvey.Core;
using AITSurvey.Core.Implementation;
using System;
using System.Web.UI;

namespace AITSurvey
{
    public partial class RespondentDetail : Page
    {
        private RespondentService _respondentService;

        // Initialize the RespondentService object in the Page_Load event
        protected void Page_Load(object sender, EventArgs e)
        {
            _respondentService = new RespondentService();
        }

        // Event handler for the Submit button click
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the survey ID from the Session object
                int.TryParse(Session["SurveyId"]?.ToString(), out var surveyId);

                // Create a new Respondent object with the input values
                var respondent = new Respondent
                {
                    Email = txtEmail.Text,
                    DateCreated = DateTime.Now,
                    IpAddress = GetIpAddress(),
                };

                // Call the Create method of RespondentService to save the respondent in the database
                var respondentId = _respondentService.Create(surveyId, respondent);

                // Save the respondent ID in the Session object
                Session["RespondentId"] = respondentId;

                // Redirect to the appropriate page based on the value of the Register checkbox
                if (respondentId > 0)
                {
                    Response.Redirect(chkRegister.Checked ? "~/RespondentProfile" : "~/Questions");
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error: " + ex.Message;
            }
        }


        /// <summary>
        /// Gets the IP address of the current user.
        /// </summary>
        /// <returns>The IP address of the current user as a string.</returns>
        public static string GetIpAddress()
        {
            // Get the current HTTP context
            System.Web.HttpContext context = System.Web.HttpContext.Current;

            // Try to get the IP address from the HTTP_X_FORWARDED_FOR header (if available)
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                // If there are multiple IP addresses, return only the first one
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            // If the IP address could not be obtained from the HTTP_X_FORWARDED_FOR header, return the REMOTE_ADDR value
            return context.Request.ServerVariables["REMOTE_ADDR"];
        }

    }
}