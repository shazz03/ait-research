﻿using AITSurvey.Core.Implementation;
using AITSurvey.Core.Models;
using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AITSurvey
{
    public partial class RespondentSearch : Page
    {
        private readonly SelectListItemService _selectListItemService;
        private readonly RespondentSearchService _respondentSearchService;
        public RespondentSearch()
        {
            _selectListItemService = new SelectListItemService();
            _respondentSearchService = new RespondentSearchService();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["StaffId"] == null)
            {
                Response.Redirect("~/StaffLogin");
            }
            if (!IsPostBack)
            {
                LoadAgeGroup();
                LoadState();
                LoadGender();
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Search();
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }

        private void Search()
        {
            var search = new RespondentSearchRequest
            {
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                AgeRangeId = int.Parse(ddlAgeGroup.SelectedValue),
                StateId = int.Parse(ddlState.SelectedValue),
                Suburb = txtSuburb.Text,
                Postcode = txtPostcode.Text,
                GenderId = int.Parse(ddlGender.SelectedValue),
                Email = txtEmail.Text
            };

            var result = _respondentSearchService.Search(search);

            gvRespondent.DataSource = result;
            gvRespondent.DataBind();
        }

        /// <summary>
        /// Loads age group options into the dropdown list from the select list item service
        /// </summary>
        private void LoadAgeGroup()
        {
            try
            {
                // retrieve age group options from the select list item service and create a new list of ListItems
                var list = (from s in _selectListItemService.LoadAgeGroup()
                            select new ListItem { Text = s.Text, Value = s.Value }).ToArray();
                // add the ListItems to the age group dropdown list and bind the data
                if (list != null)
                {
                    ddlAgeGroup.Items.AddRange(list);
                    ddlAgeGroup.DataBind();
                }
            }
            catch (Exception)
            {
                // catch any exceptions that occur during the loading of age group options
                //log
            }
        }

        /// <summary>
        /// Loads Gender options into the dropdown list from the select list item service
        /// </summary>
        private void LoadGender()
        {
            try
            {
                // retrieve Gender options from the select list item service and create a new list of ListItems
                var list = (from s in _selectListItemService.LoadGender()
                            select new ListItem { Text = s.Text, Value = s.Value }).ToArray();
                // add the ListItems to the Gender dropdown list and bind the data
                if (list != null)
                {
                    ddlGender.Items.AddRange(list);
                    ddlGender.DataBind();
                }
            }
            catch (Exception)
            {
                // catch any exceptions that occur during the loading of age group options
                //log
            }
        }

        /// <summary>
        /// Loads State options into the dropdown list from the select list item service
        /// </summary>
        private void LoadState()
        {
            try
            {
                // retrieve state options from the select list item service and create a new list of ListItems
                var list = (from s in _selectListItemService.LoadState()
                            select new ListItem { Text = s.Text, Value = s.Value }).ToArray();
                // add the ListItems to the state dropdown list and bind the data
                if (list != null)
                {
                    ddlState.Items.AddRange(list);
                    ddlState.DataBind();
                }
            }
            catch (Exception)
            {
                // catch any exceptions that occur during the loading of state options
                //log
            }
        }

    }
}