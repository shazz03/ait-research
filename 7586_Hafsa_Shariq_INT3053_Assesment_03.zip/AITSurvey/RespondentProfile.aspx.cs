﻿using AITSurvey.Core.Implementation;
using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AITSurvey
{
    public partial class RespondentProfile : Page
    {
        private readonly SelectListItemService _selectListItemService;
        private readonly RespondentService _respondentService;

        public RespondentProfile()
        {
            _selectListItemService = new SelectListItemService();
            _respondentService = new RespondentService();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if the page is being loaded for the first time
            if (!IsPostBack)
            {
                // Load the gender and age group lists for the dropdowns
                LoadGender();
                LoadAgeGroup();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the survey and respondent IDs from session state
                int.TryParse(Session["SurveyId"]?.ToString(), out var surveyId);
                var respondentId = int.Parse(Session["RespondentId"].ToString());

                // Create a new respondent profile object with the data from the form fields
                var profile = new Core.Models.RespondentProfile
                {
                    DateCreated = DateTime.Now,
                    DateOfBirth = DateTime.Parse(txtBirthdayDate.Text),
                    FirstName = txtFirstName.Text,
                    LastName = txtLastName.Text,
                    AgeGroup = new Core.Models.AgeGroup
                    {
                        Id = int.Parse(ddlAgeGroup.SelectedValue)
                    },
                    Gender = new Core.Models.Gender
                    {
                        Id = int.Parse(ddlGender.SelectedValue)
                    },
                    ContactNumber = txtContactNumber.Text,
                };

                // Call the respondent service to create the profile
                _respondentService.CreateProfile(respondentId, profile);

                // Redirect the user to the respondent address page
                Response.Redirect($"~/RespondentAddress");
            }
            catch (Exception ex)
            {
                // Display an error message if an exception occurs
                lblMessage.Text = "Error: " + ex.Message;
            }
        }

        protected void btnSkip_Click(object sender, EventArgs e)
        {
            // Redirect the user to the respondent address page if they choose to skip the profile creation
            Response.Redirect($"~/RespondentAddress");
        }

        /// <summary>
        /// Loads gender options into the dropdown list from the select list item service
        /// </summary>
        private void LoadGender()
        {
            try
            {
                // retrieve gender options from the select list item service and create a new list of ListItems
                var list = (from s in _selectListItemService.LoadGender()
                            select new ListItem { Text = s.Text, Value = s.Value }).ToArray();
                // add the ListItems to the gender dropdown list and bind the data
                if (list != null)
                {
                    ddlGender.Items.AddRange(list);
                    ddlGender.DataBind();
                }
            }
            catch (Exception)
            {
                // catch any exceptions that occur during the loading of gender options
                //log
            }
        }

        /// <summary>
        /// Loads age group options into the dropdown list from the select list item service
        /// </summary>
        private void LoadAgeGroup()
        {
            try
            {
                // retrieve age group options from the select list item service and create a new list of ListItems
                var list = (from s in _selectListItemService.LoadAgeGroup()
                            select new ListItem { Text = s.Text, Value = s.Value }).ToArray();
                // add the ListItems to the age group dropdown list and bind the data
                if (list != null)
                {
                    ddlAgeGroup.Items.AddRange(list);
                    ddlAgeGroup.DataBind();
                }
            }
            catch (Exception)
            {
                // catch any exceptions that occur during the loading of age group options
                //log
            }
        }

    }
}