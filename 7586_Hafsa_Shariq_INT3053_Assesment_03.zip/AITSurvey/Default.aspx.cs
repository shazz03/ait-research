﻿using System;
using System.Web.UI;

namespace AITSurvey
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ClearSession();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            var surveyId = 1;
            Session[$"Questions-{surveyId}"] = null;
            Session["SurveyId"] = surveyId;
            Response.Redirect($"~/RespondentDetail");
        }

        private void ClearSession()
        {
            int.TryParse(Session["SurveyId"]?.ToString(), out var surveyId);
            Session[$"Answer_{surveyId}"] = null;
            Session["SurveyId"] = null;
            Session[$"Questions-{surveyId}"] = null;
        }
    }
}