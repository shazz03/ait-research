﻿namespace AITSurvey.Core
{
    public class TypeOptions
    {
        public const string YesOrNo = "YesOrNo";
        public const string SingleChoice = "SingleChoice";
        public const string MultipleChoice = "MultipleChoice";
    }
}
