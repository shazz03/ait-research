﻿
namespace AITSurvey.Core.Models
{
    public class RespondentSearchResult
    {
        public Respondent Respondent { get; set; }
        public RespondentProfile Profile { get; set; }
        public Address Address { get; set; }
    }
}
