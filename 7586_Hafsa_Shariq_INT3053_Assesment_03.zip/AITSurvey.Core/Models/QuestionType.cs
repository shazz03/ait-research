﻿namespace AITSurvey.Core.Models
{
    public class QuestionType
    {
        public int Id { get; set; }
        public string TypeName { get; set; }
    }
}
