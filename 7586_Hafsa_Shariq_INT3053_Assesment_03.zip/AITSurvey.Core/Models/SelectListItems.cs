﻿

namespace AITSurvey.Core.Models
{
    public class SelectListItems
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
