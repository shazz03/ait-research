﻿namespace AITSurvey.Core.Models
{
    public class QuestionGroup
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
    }
}
