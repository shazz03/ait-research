﻿namespace AITSurvey.Core
{
    public class Staff
    {
        public int Id { get; set; }
        public string UserName { get; set; }
    }
}
