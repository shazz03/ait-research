﻿
namespace AITSurvey.Core.Models
{
    public class AnswerViewDto
    {
        public string QuestionText { get; set; }
        public string AnswerText { get; set; }
    }
}
